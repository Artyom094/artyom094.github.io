class AuthService {
    constructor() {
        this.apiUrl = '/api/auth';
        this.token = localStorage.getItem('userToken');
    }

    async login(email, password) {
        try {
            // Aquí irá la llamada real a la API
            // const response = await fetch(`${this.apiUrl}/login`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ email, password })
            // });
            // const data = await response.json();
            // this.token = data.token;
            // localStorage.setItem('userToken', this.token);
            
            // Simulación de respuesta
            return new Promise((resolve) => {
                setTimeout(() => {
                    if (email && password) {
                        const mockToken = 'mock-jwt-token';
                        localStorage.setItem('userToken', mockToken);
                        resolve({ success: true });
                    } else {
                        throw new Error('Credenciales inválidas');
                    }
                }, 1000);
            });
        } catch (error) {
            console.error('Error en login:', error);
            throw error;
        }
    }

    async register(userData) {
        try {
            // Aquí irá la llamada real a la API
            // const response = await fetch(`${this.apiUrl}/register`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(userData)
            // });
            // return await response.json();
            
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve({ success: true });
                }, 1000);
            });
        } catch (error) {
            console.error('Error en registro:', error);
            throw error;
        }
    }

    logout() {
        localStorage.removeItem('userToken');
        this.token = null;
        window.location.href = 'login.html';
    }

    isAuthenticated() {
        return !!this.token;
    }

    redirectIfNotAuth() {
        if (!this.isAuthenticated()) {
            window.location.href = 'login.html';
        }
    }
}

const authService = new AuthService();
