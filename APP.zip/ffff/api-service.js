// js/api.js - Servicio API central para CityVibes

/**
 * Clase de servicio para comunicación con la API
 */
class ApiService {
    constructor(baseURL) {
        this.baseURL = baseURL || 'https://cityvibess.bsite.net/api';
        this.token = localStorage.getItem('authToken');
    }

    /**
     * Configura el token para solicitudes autenticadas
     * @param {string} token - Token JWT
     */
    setAuthToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('authToken', token);
        } else {
            localStorage.removeItem('authToken');
        }
    }

    /**
     * Construye las cabeceras para las solicitudes a la API
     * @param {boolean} includeAuth - Si se debe incluir el token de autenticación
     * @returns {Headers} - Objeto Headers para fetch
     */
    getHeaders(includeAuth = true) {
        const headers = new Headers({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        });

        if (includeAuth && this.token) {
            headers.append('Authorization', `Bearer ${this.token}`);
        }

        return headers;
    }

    /**
     * Realiza una solicitud GET a la API
     * @param {string} endpoint - Endpoint de la API
     * @param {boolean} auth - Si la solicitud requiere autenticación
     * @returns {Promise<any>} - Promesa con la respuesta
     */
    async get(endpoint, auth = true) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'GET',
                headers: this.getHeaders(auth)
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('API GET Error:', error);
            throw new Error('Error de conexión con el servidor');
        }
    }

    /**
     * Realiza una solicitud POST a la API
     * @param {string} endpoint - Endpoint de la API
     * @param {object} data - Datos a enviar
     * @param {boolean} auth - Si la solicitud requiere autenticación
     * @returns {Promise<any>} - Promesa con la respuesta
     */
    async post(endpoint, data, auth = true) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'POST',
                headers: this.getHeaders(auth),
                body: JSON.stringify(data)
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('API POST Error:', error);
            throw new Error('Error de conexión con el servidor');
        }
    }

    /**
     * Realiza una solicitud PUT a la API
     * @param {string} endpoint - Endpoint de la API
     * @param {object} data - Datos a enviar
     * @returns {Promise<any>} - Promesa con la respuesta
     */
    async put(endpoint, data) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'PUT',
                headers: this.getHeaders(),
                body: JSON.stringify(data)
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('API PUT Error:', error);
            throw new Error('Error de conexión con el servidor');
        }
    }

    /**
     * Realiza una solicitud DELETE a la API
     * @param {string} endpoint - Endpoint de la API
     * @returns {Promise<any>} - Promesa con la respuesta
     */
    async delete(endpoint) {
        try {
            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'DELETE',
                headers: this.getHeaders()
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('API DELETE Error:', error);
            throw new Error('Error de conexión con el servidor');
        }
    }

    /**
     * Sube un archivo a la API
     * @param {string} endpoint - Endpoint de la API
     * @param {FormData} formData - FormData con los archivos y datos
     * @returns {Promise<any>} - Promesa con la respuesta
     */
    async uploadFile(endpoint, formData) {
        try {
            const headers = new Headers();
            if (this.token) {
                headers.append('Authorization', `Bearer ${this.token}`);
            }

            const response = await fetch(`${this.baseURL}${endpoint}`, {
                method: 'POST',
                headers: headers,
                body: formData
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('API Upload Error:', error);
            throw new Error('Error de conexión con el servidor');
        }
    }

    /**
     * Maneja la respuesta de la API y extrae los datos JSON o maneja errores
     * @param {Response} response - Objeto Response de fetch
     * @returns {Promise<any>} - Datos de la respuesta
     */
    async handleResponse(response) {
        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            // Si hay un error 401, el token podría haber expirado
            if (response.status === 401) {
                // Eliminar token y redirigir al login
                this.setAuthToken(null);
                if (window.location.pathname !== '/login.html') {
                    window.location.href = '/login.html?expired=true';
                }
            }

            const errorMessage = data.message || data.error || 'Error en la solicitud';
            throw new Error(errorMessage);
        }

        return data;
    }

    /**
     * Verifica si el usuario está autenticado
     * @returns {boolean} - true si hay un token de autenticación
     */
    isAuthenticated() {
        return !!this.token;
    }
}

// Exportamos una instancia para uso en toda la aplicación
const apiService = new ApiService();

// Para uso en casos donde se necesite modificar la URL base
window.configureApiService = function(baseURL) {
    apiService.baseURL = baseURL;
};
