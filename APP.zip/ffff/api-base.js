// js/api.js - Servicio de API para CityVibes

const apiService = {
    // Obtener los headers para las peticiones
    getHeaders: function(includeAuth = true) {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        // Incluir token de autenticación si está disponible y se requiere
        if (includeAuth) {
            const token = localStorage.getItem('authToken');
            if (token) {
                headers['Authorization'] = `Bearer ${token}`;
            }
        }

        return headers;
    },

    // Realizar una petición GET
    get: async function(endpoint, auth = true) {
        try {
            const response = await fetch(`${API_CONFIG.baseUrl}${endpoint}`, {
                method: 'GET',
                headers: this.getHeaders(auth)
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('Error en petición GET:', error);
            throw new Error('Error de conexión con el servidor');
        }
    },

    // Realizar una petición POST
    post: async function(endpoint, data, auth = true) {
        try {
            const response = await fetch(`${API_CONFIG.baseUrl}${endpoint}`, {
                method: 'POST',
                headers: this.getHeaders(auth),
                body: JSON.stringify(data)
            });

            return this.handleResponse(response);
        } catch (error) {
            console.error('Error en petición POST:', error);
            throw new Error('Error de conexión con el servidor');
        }
    },

    // Manejar la respuesta
    handleResponse: async function(response) {
        let data;
        try {
            data = await response.json();
        } catch (e) {
            data = null;
        }

        if (!response.ok) {
            // Si el error es 401, podría ser un token expirado
            if (response.status === 401) {
                // Limpiar token y redirigir a login
                localStorage.removeItem('authToken');
                if (window.location.pathname !== '/login.html') {
                    window.location.href = '/login.html?session=expired';
                }
            }

            const errorMsg = (data && data.message) || 'Error en la solicitud';
            throw new Error(errorMsg);
        }

        return data;
    }
};
