class UserProfileService {
    constructor() {
        this.baseUrl = API_CONFIG.BASE_URL;
    }

    async getUserProfile() {
        try {
            const response = await fetch(`${this.baseUrl}/user/profile`, {
                headers: getAuthHeaders()
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching user profile:', error);
            throw error;
        }
    }

    async getFavoriteCategories() {
        try {
            const response = await fetch(`${this.baseUrl}/user/categories`, {
                headers: getAuthHeaders()
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching favorite categories:', error);
            throw error;
        }
    }

    async getUserPlaces() {
        try {
            const response = await fetch(`${this.baseUrl}/user/places`, {
                headers: getAuthHeaders()
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching user places:', error);
            throw error;
        }
    }

    async getRecentActivity() {
        try {
            const response = await fetch(`${this.baseUrl}/user/activity`, {
                headers: getAuthHeaders()
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching recent activity:', error);
            throw error;
        }
    }
}

const userProfileService = new UserProfileService();
