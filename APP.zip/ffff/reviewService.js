class ReviewService {
    constructor() {
        this.baseUrl = API_CONFIG.BASE_URL;
    }

    async getReviews(category = null) {
        try {
            let url = `${this.baseUrl}/reviews`;
            if (category) {
                url += `?category=${category}`;
            }
            const response = await fetch(url, {
                headers: getAuthHeaders()
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching reviews:', error);
            throw error;
        }
    }

    async addReview(reviewData) {
        try {
            const response = await fetch(`${this.baseUrl}/reviews`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify(reviewData)
            });
            return await response.json();
        } catch (error) {
            console.error('Error adding review:', error);
            throw error;
        }
    }
}

const reviewService = new ReviewService();
