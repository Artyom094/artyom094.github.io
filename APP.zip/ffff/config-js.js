// js/config.js - Archivo de configuración para CityVibes

// Configuración de la API
const API_CONFIG = {
    baseUrl: 'https://cityvibess.bsite.net/api',
    timeout: 15000, // Tiempo de espera en milisegundos
};

// No modificar esta parte - Para uso interno de la aplicación
if (typeof module !== 'undefined') {
    module.exports = API_CONFIG;
}
