// Script para integrar la página login.html con la API
document.addEventListener('DOMContentLoaded', () => {
    // Referencias a elementos del DOM
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authTabs = document.querySelectorAll('.auth-tab');
    const authForms = document.querySelectorAll('.auth-form');
    const messageDiv = document.querySelector('.auth-message');

    console.log('Login integration script loaded');
    console.log('Base API URL: ' + API_URL);

    // Verificar si ya hay sesión (opcional)
    if (loginService.isAuthenticated()) {
        console.log('Usuario ya autenticado, redirigiendo...');
        // Descomenta la siguiente línea cuando todo esté listo
        // window.location.href = 'index.html';
    }

    // Función para mostrar mensajes
    function showMessage(message, type = 'info') {
        console.log(`Mensaje (${type}): ${message}`);
        messageDiv.textContent = message;
        messageDiv.className = `auth-message ${type}`;
        messageDiv.style.display = 'block';
        
        // Para mensajes de éxito o error, ocultarlos después de un tiempo
        if (type === 'success' || type === 'error') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        }
    }

    // Manejar cambio de tabs
    authTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Identificar qué tab fue clickeada
            const tabId = tab.getAttribute('data-tab');
            console.log('Tab clicked:', tabId);
            
            // Actualizar tabs activas
            authTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Actualizar formularios activos
            authForms.forEach(form => form.classList.remove('active'));
            
            // Activar el formulario correspondiente
            const targetForm = document.getElementById(`${tabId}Form`);
            if (targetForm) {
                targetForm.classList.add('active');
                console.log('Form activated:', tabId + 'Form');
            } else {
                console.error('Form not found:', tabId + 'Form');
            }
            
            // Ocultar mensajes anteriores
            messageDiv.style.display = 'none';
        });
    });

    // Manejar envío del formulario de login
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Formulario de login enviado');
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            if (!email || !password) {
                showMessage('Por favor, completa todos los campos', 'error');
                return;
            }
            
            try {
                showMessage('Iniciando sesión...', 'info');
                
                // Llamada real a la API
                const response = await loginService.login({ email, password });
                console.log('Respuesta de login:', response);
                
                showMessage('¡Inicio de sesión exitoso!', 'success');
                
                // Redireccionar después de un breve momento
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
                
            } catch (error) {
                showMessage(`Error: ${error.message || 'No se pudo iniciar sesión'}`, 'error');
            }
        });
    } else {
        console.error('Login form not found');
    }

    // Manejar envío del formulario de registro
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Formulario de registro enviado');
            
            // Obtener valores del formulario
            const username = document.getElementById('username').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validaciones básicas
            if (!username || !email || !password || !confirmPassword) {
                showMessage('Por favor, completa todos los campos', 'error');
                return;
            }
            
            // Validar contraseñas
            if (password !== confirmPassword) {
                showMessage('Las contraseñas no coinciden', 'error');
                return;
            }
            
            try {
                showMessage('Creando cuenta...', 'info');
                
                console.log('Enviando datos de registro al servidor:', {
                    username,
                    email,
                    password
                });
                
                // Llamada real a la API
                const response = await loginService.register({
                    username,
                    email,
                    password
                });
                
                console.log('Respuesta de registro:', response);
                
                showMessage('¡Cuenta creada exitosamente!', 'success');
                
                // Redireccionar al index después de un breve momento
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
                
            } catch (error) {
                showMessage(`Error: ${error.message || 'No se pudo crear la cuenta'}`, 'error');
            }
        });
    } else {
        console.error('Register form not found');
    }

    // Configurar visibilidad de contraseñas
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', () => {
            const input = button.previousElementSibling;
            if (input && input.type) {
                if (input.type === 'password') {
                    input.type = 'text';
                    button.textContent = '👁️‍🗨️';
                } else {
                    input.type = 'password';
                    button.textContent = '👁️';
                }
            }
        });
    });

    // Verificar si hay un parámetro en la URL indicando sesión expirada
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('session') && urlParams.get('session') === 'expired') {
        showMessage('Tu sesión ha expirado. Por favor inicia sesión nuevamente.', 'warning');
    }
});