// js/loginService.js - Servicio para manejar login, registro y operaciones CRUD

// URL base de la API
const API_URL = 'https://cityvibess.bsite.net';

const loginService = {
    // -------- AUTENTICACIÓN --------
    
    // Función para registrar un nuevo usuario
    register: async function(userData) {
        console.log('Intentando registrar usuario con datos:', userData);
        
        try {
            const response = await fetch(`${API_URL}/api/users/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    Username: userData.username || '',
                    Email: userData.email || '',
                    Password: userData.password || ''
                })
            });

            console.log('Respuesta del servidor:', response.status);
            
            // Procesar la respuesta
            if (response.ok) {
                const data = await response.json();
                console.log('Datos recibidos:', data);
                
                // Si hay token, lo guardamos
                if (data.token) {
                    localStorage.setItem('authToken', data.token);
                    
                    // También podemos guardar datos del usuario
                    if (data.user) {
                        localStorage.setItem('currentUser', JSON.stringify(data.user));
                    }
                }
                
                return data;
            } else {
                // Si hay un error, intentamos obtener el mensaje de error
                try {
                    const errorData = await response.json();
                    console.error('Error de registro (datos):', errorData);
                    throw new Error(errorData?.message || 'Error en el registro');
                } catch (parseError) {
                    console.error('Error al procesar respuesta de error:', parseError);
                    throw new Error(`Error en el registro (${response.status})`);
                }
            }
        } catch (error) {
            console.error('Error de registro:', error);
            throw error;
        }
    },

    // Función para iniciar sesión
    login: async function(credentials) {
        try {
            const response = await fetch(`${API_URL}/api/users/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    username: credentials.username || credentials.email || '',
                    password: credentials.password || ''
                })
            });

            // Procesar la respuesta
            if (response.ok) {
                const data = await response.json();
                
                // Si hay token, lo guardamos
                if (data.token) {
                    localStorage.setItem('authToken', data.token);
                    
                    // También podemos guardar datos del usuario
                    if (data.user) {
                        localStorage.setItem('currentUser', JSON.stringify(data.user));
                    }
                }
                
                return data;
            } else {
                // Si hay un error, intentamos obtener el mensaje de error
                try {
                    const errorData = await response.json();
                    throw new Error(errorData?.message || 'Error en el inicio de sesión');
                } catch (parseError) {
                    throw new Error(`Error en el inicio de sesión (${response.status})`);
                }
            }
        } catch (error) {
            console.error('Error de login:', error);
            throw error;
        }
    },

    // Verificar si hay un usuario autenticado
    isAuthenticated: function() {
        return !!localStorage.getItem('authToken');
    },

    // Cerrar sesión
    logout: function() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        // Redirigir a la página de login si es necesario
        window.location.href = 'login.html';
    },

    // Obtener el token actual
    getToken: function() {
        return localStorage.getItem('authToken');
    },

    // -------- OPERACIONES CRUD --------

    // Obtener headers con autenticación
    getAuthHeaders: function() {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        
        const token = this.getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        return headers;
    },

    // CREATE - Crear un nuevo recurso
    create: async function(endpoint, data) {
        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                method: 'POST',
                headers: this.getAuthHeaders(),
                body: JSON.stringify(data)
            });

            if (response.ok) {
                return await response.json();
            } else {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData?.message || `Error al crear recurso (${response.status})`);
            }
        } catch (error) {
            console.error('Error en operación CREATE:', error);
            throw error;
        }
    },

    // READ - Obtener recursos
    read: async function(endpoint) {
        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                method: 'GET',
                headers: this.getAuthHeaders()
            });

            if (response.ok) {
                return await response.json();
            } else {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData?.message || `Error al obtener recursos (${response.status})`);
            }
        } catch (error) {
            console.error('Error en operación READ:', error);
            throw error;
        }
    },

    // UPDATE - Actualizar un recurso existente
    update: async function(endpoint, data) {
        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                method: 'PUT',
                headers: this.getAuthHeaders(),
                body: JSON.stringify(data)
            });

            if (response.ok) {
                return await response.json();
            } else {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData?.message || `Error al actualizar recurso (${response.status})`);
            }
        } catch (error) {
            console.error('Error en operación UPDATE:', error);
            throw error;
        }
    },

    // DELETE - Eliminar un recurso
    delete: async function(endpoint) {
        try {
            const response = await fetch(`${API_URL}${endpoint}`, {
                method: 'DELETE',
                headers: this.getAuthHeaders()
            });

            if (response.ok) {
                return true; // Suponemos que DELETE puede devolver o no un cuerpo de respuesta
            } else {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData?.message || `Error al eliminar recurso (${response.status})`);
            }
        } catch (error) {
            console.error('Error en operación DELETE:', error);
            throw error;
        }
    }
};