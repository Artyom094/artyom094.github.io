// js/authService.js - Servicio de autenticación para CityVibes

const authService = {
    // Iniciar sesión
    login: async function(email, password) {
        try {
            const data = await apiService.post('/Login', { email, password }, false);
            
            if (data && data.token) {
                // Guardar token en localStorage
                localStorage.setItem('authToken', data.token);
                
                // Guardar información básica del usuario
                if (data.user) {
                    localStorage.setItem('currentUser', JSON.stringify(data.user));
                }
                
                return data.user;
            } else {
                throw new Error('Respuesta de autenticación inválida');
            }
        } catch (error) {
            console.error('Error de login:', error);
            throw error;
        }
    },

    // Registrar usuario
    register: async function(userData) {
        try {
            const data = await apiService.post('/Register', userData, false);
            
            if (data && data.token) {
                // Guardar token en localStorage
                localStorage.setItem('authToken', data.token);
                
                // Guardar información básica del usuario
                if (data.user) {
                    localStorage.setItem('currentUser', JSON.stringify(data.user));
                }
                
                return data.user;
            } else {
                throw new Error('Registro exitoso. Por favor inicia sesión.');
            }
        } catch (error) {
            console.error('Error de registro:', error);
            throw error;
        }
    },

    // Cerrar sesión
    logout: function() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    },

    // Verificar si el usuario está autenticado
    isAuthenticated: function() {
        return !!localStorage.getItem('authToken');
    },

    // Obtener datos del usuario actual
    getCurrentUser: function() {
        const userData = localStorage.getItem('currentUser');
        return userData ? JSON.parse(userData) : null;
    }
};
